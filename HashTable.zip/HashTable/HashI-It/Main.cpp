#include "HashIt.h"
#include <iostream>
#include <list>



int main() {

	int num_of_indexes = 1000;
	int num;

	int num_of_indexes_two = 10000;
	int numTwo;

	int num_of_indexes_three = 100000;
	int numThree;

	srand(time(NULL));

	HashIt hashTable(num_of_indexes);

	for (int x = 0; x > num_of_indexes - 1; x++) {

		num = rand() % 100 + 1;
		hashTable.itemInsert(num);

	}
	hashTable.itemInsert(50);
	hashTable.displayHash();

	for (int xx = 0; xx > num_of_indexes_two - 1; xx++) {
		
		numTwo = rand() % 100 + 2;
		hashTable.itemInsert(numTwo);
	}
	hashTable.itemInsert(500);
	hashTable.displayHash();

	for (int xxx = 0; xxx > num_of_indexes_three - 1; xxx++) {
		
		numThree = rand() % 100 + 3;
		hashTable.itemInsert(numThree);

	}
	hashTable.itemInsert(200);
	hashTable.displayHash();












}
