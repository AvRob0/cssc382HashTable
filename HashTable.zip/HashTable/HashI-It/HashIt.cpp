#include "HashIt.h"
#include<iostream>
#include <list>

HashIt::HashIt(int h) {
	
	this->hashIndexes = h;
	hashT = new std::list <int> [hashIndexes];

}

void HashIt::itemInsert(int key) {

	int index = hashFunction(key);
	hashT[index].push_back(key);
}

void HashIt::itemDeletion(int key) {

	int index = hashFunction(key);
	std::list<int>::iterator ii;
	for (ii = hashT[hashIndexes].begin(); ii != hashT[hashIndexes].end(); ii++) {
		if (*ii == key)
			break;
	}
	if (ii != hashT[hashIndexes].end())
		hashT[hashIndexes].erase(ii);
}

void HashIt::displayHash() {

	for (int i = 0; i < hashIndexes; i++) {
		std::cout << " HashT: " << i << std::endl;
		for (auto x : hashT[i])
			std::cout << " --> " << x ;
	} 
	
}

int HashIt::hashFunction(int n) {

	return n % 599;

}

int HashIt::hashTwoFunction(int nn)
{
	return nn % 400;
}

int hashThreeFunction(int nnn) {

	return nnn % 800;
}
