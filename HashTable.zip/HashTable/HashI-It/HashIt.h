#pragma once
#include<iostream>
#include <list>

class HashIt {

	int hashIndexes;
	std::list<int> *hashT;

public:

	HashIt(int hash);
	void itemInsert(int key);
	void itemDeletion(int key);
	void displayHash();
	int hashFunction(int key);
	int hashTwoFunction(int key);
	int hashThreeFunction(int key);



};
